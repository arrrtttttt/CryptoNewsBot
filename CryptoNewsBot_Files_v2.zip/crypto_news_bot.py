import os
import time
import feedparser
import telebot

bot_token = os.getenv("BOT_TOKEN")
channel_id = os.getenv("CHANNEL_ID")

bot = telebot.TeleBot(bot_token)

sources = [
    "https://cointelegraph.com/rss",
    "https://news.bitcoin.com/feed/",
    "https://decrypt.co/feed"
]

posted_links = set()

def fetch_and_post():
    global posted_links
    for url in sources:
        feed = feedparser.parse(url)
        for entry in feed.entries[:5]:
            if entry.link not in posted_links:
                message = f"📰 <b>{entry.title}</b>\n\n{entry.link}"
                bot.send_message(channel_id, message, parse_mode='HTML', disable_web_page_preview=True)
                posted_links.add(entry.link)
                time.sleep(2)

print("Бот запущен...")
while True:
    fetch_and_post()
    time.sleep(600)
